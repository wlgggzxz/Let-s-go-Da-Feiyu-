# 去吧！大肥鱼！· Android 工程

Pokopia 存档编辑器的 Android 版本，基于 WebView 加载本地网页。

## 云端打包 · 电脑路线

1. 在 GitHub 新建仓库，把本目录全部文件推上去
2. 打开仓库的 **Actions** 标签页
3. 左侧选 **Build APK** → 右侧 **Run workflow** → 再点绿色按钮
4. 等 3~5 分钟，进入该次运行，页面底部 **Artifacts** 下载 `dafeiyu-apk`
5. 解压得到 `app-debug.apk`，传到手机安装（需允许未知来源）

## 云端打包 · 手机路线（只需上传 2 个文件）

1. 手机浏览器打开 GitHub，切到**桌面版网站**
2. 新建空仓库
3. Add file → Upload files → 上传 `dafeiyu-android-project.zip`
4. Add file → Create new file → 文件名填 `.github/workflows/build-apk.yml` → 粘贴 `build-apk.yml` 内容 → Commit
5. Actions → Build APK → Run workflow
6. 跑完后在 Artifacts 下载 `dafeiyu-apk`，解压安装

工作流会自动解压仓库里的 zip，再编译其中的工程。

## 本地打包（需要 Android Studio / SDK）

```bash
gradle assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

## 网页资源怎么更新

网页部分由主工程的构建脚本生成，不要手改 `app/src/main/assets/index.html`：

```bash
cd ..
node build_android.mjs      # 用最新构建覆盖 assets/index.html
```

## 目录说明

```
app/src/main/java/com/whale/dafeiyu/MainActivity.java   WebView 容器
app/src/main/assets/index.html                          应用本体（自动生成）
app/src/main/res/mipmap-*/ic_launcher.png               图标
.github/workflows/build-apk.yml                         云端打包流程
```

## 原生桥接

WebView 不支持 `<a download>` 的 blob 下载，所以 `MainActivity` 暴露了一个 JS 接口：

```js
window.WhaleSaver.save(fileName, base64String)
```

网页侧的 `android/overrides.js` 会拦截导出动作，把 zip 转成 base64 交给原生，存进系统「下载」目录并弹提示。

文件选择（`<input type="file">`）由 `WebChromeClient.onShowFileChooser` 接管，会唤起系统文件选择器。

## 已知限制

- debug 签名，仅供自用；上架需配置正式签名
- 保存路径依赖 MediaStore（Android 10+）或外部存储下载目录（9 及以下）
